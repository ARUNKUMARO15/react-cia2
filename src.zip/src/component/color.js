import React, { useState } from "react";
// import ReactDOM from "react-dom/client";

function Coloureffect() {
  const [color, setColor] = useState("red");
    
  return (
    <>
      <p>Colour Changing Effect {color}!</p>
      <button
        type="button"
        onClick={() => setColor("blue")}
      >Blue</button>
      <button
        type="button"
        onClick={() => setColor("red")}
      >Red</button>
      <button
        type="button"
        onClick={() => setColor("pink")}
      >Pink</button>
      <button
        type="button"
        onClick={() => setColor("green")}
      >Green</button>
    </>
  );
}

export default Coloureffect;
