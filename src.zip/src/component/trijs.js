import React from "react";
import './trics.css'; 
function showBlock()
{
    if(document.getElementById('block').style.display=="block"){
        document.getElementById('block').style.display="none";
        // document.getElementById('block').style.transition:"2s";
    }
    else{
        document.getElementById('block').style.display="block";
    }
}
function colorChange(i)
{
    if(document.getElementById("box").style.backgroundColor=="black")
    {
        document.getElementById("box").style.backgroundColor=i;
    }
    else{
        document.getElementById("box").style.backgroundColor="black";

    }
}
class Dropdown extends React.Component
{
    render()
    {
        return(
            <>
                
                    <div id="box" onMouseEnter={showBlock} onMouseLeave={showBlock}>
                        <h1>Select</h1>
                        <div id="block">
                            <div id="red" class="ele" onMouseEnter={()=>colorChange('red')} onMouseLeave={colorChange}>
                                <h1>Red</h1>
                            </div>
                            <div id="blue" class="ele" onMouseEnter={()=>colorChange('blue')} onMouseLeave={colorChange}>
                                <h1>Blue</h1>
                            </div>
                            <div id="green" class="ele" onMouseEnter={()=>colorChange('green')} onMouseLeave={colorChange}>
                                <h1>Green</h1>
                            </div>
                        </div>
                    </div>
                
            </>
        )
    }
}

export default Dropdown;