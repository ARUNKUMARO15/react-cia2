import './App.css';
import React from 'react';
import Colourchanger from './component/dropdown';
function App() {
  return (
    <>
    <div className="App">
          <Colourchanger/>
    </div>
    </>
  );
}


export default App;
